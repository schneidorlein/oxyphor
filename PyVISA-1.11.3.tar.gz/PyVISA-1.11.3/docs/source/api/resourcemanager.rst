.. _api_resourcemanager:

Resource Manager
----------------

.. autoclass:: pyvisa.highlevel.ResourceInfo

.. autoclass:: pyvisa.highlevel.ResourceManager
    :members: close, session, list_resources, list_resources_info, resource_info, open_bare_resource, open_resource, last_status
