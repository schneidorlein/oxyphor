.. _advanced:

Advanced topics
===============

This section of the documentation will cover the internal details of PyVISA.
In particular, it will explain in details how PyVISA manage backends.

.. toctree::
    :maxdepth: 2

    architecture
    backends
    continuous_integration
